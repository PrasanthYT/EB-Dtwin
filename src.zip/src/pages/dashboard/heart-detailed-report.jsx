"use client"

import { useState, useEffect, useRef } from "react"
import { ArrowLeft, Heart, Activity, ChevronUp, ChevronDown, X, Brain } from "lucide-react"
import { Line, LineChart, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useNavigate } from "react-router-dom"

// Sample data for the charts
const hrvData = [
  { time: "00:00", value: 45, label: "12:00 AM" },
  { time: "04:00", value: 52, label: "4:00 AM" },
  { time: "08:00", value: 38, label: "8:00 AM" },
  { time: "12:00", value: 41, label: "12:00 PM" },
  { time: "16:00", value: 47, label: "4:00 PM" },
  { time: "20:00", value: 44, label: "8:00 PM" },
  { time: "24:00", value: 49, label: "12:00 AM" },
]

const heartRateWithFoodData = [
  { time: "00:00", heartRate: 68, foodIntake: 0, label: "12:00 AM" },
  { time: "08:00", heartRate: 72, foodIntake: 1, label: "8:00 AM" },
  { time: "12:00", heartRate: 85, foodIntake: 3, label: "12:00 PM" },
  { time: "16:00", heartRate: 78, foodIntake: 2, label: "4:00 PM" },
  { time: "20:00", heartRate: 82, foodIntake: 3, label: "8:00 PM" },
  { time: "24:00", heartRate: 70, foodIntake: 0, label: "12:00 AM" },
]

// Lottie Heart Component with 2 loops
const LottieHeart = () => {
  const containerRef = useRef(null)
  const animationRef = useRef(null)

  useEffect(() => {
    let lottie = null

    const loadLottie = async () => {
      try {
        // Import lottie-web dynamically
        const lottieModule = await import("lottie-web")
        lottie = lottieModule.default

        if (containerRef.current && !animationRef.current) {
          // Load the animation data
          const response = await fetch("/heart-animation.json")
          const animationData = await response.json()

          animationRef.current = lottie.loadAnimation({
            container: containerRef.current,
            renderer: "svg",
            loop: false, // We'll control the loop manually
            autoplay: true,
            animationData: animationData,
          })

          // Set up loop counter
          let loopCount = 0
          const maxLoops = 2

          animationRef.current.addEventListener("complete", () => {
            loopCount++
            if (loopCount < maxLoops) {
              animationRef.current.goToAndPlay(0)
            }
          })
        }
      } catch (error) {
        console.error("Error loading Lottie animation:", error)
        // Fallback to CSS heart if Lottie fails
        if (containerRef.current) {
          containerRef.current.innerHTML = `
            <div class="w-24 h-24 text-red-500 flex items-center justify-center animate-pulse">
              ❤️
            </div>
          `
        }
      }
    }

    loadLottie()

    return () => {
      if (animationRef.current) {
        animationRef.current.destroy()
        animationRef.current = null
      }
    }
  }, [])

  return (
    <div className="relative w-32 h-32 flex items-center justify-center">
      <div ref={containerRef} className="w-full h-full" />
    </div>
  )
}

// Graph Popup Modal
const GraphPopup = ({ isOpen, onClose, graphType, data, title }) => {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative bg-white rounded-2xl w-[90%] max-w-md mx-4 transform transition-all duration-300 animate-in zoom-in-95">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
          <Button onClick={onClose} variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-gray-100">
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Graph Content */}
        <div className="p-6">
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: "#6b7280" }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: "#6b7280" }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                  }}
                  labelFormatter={(value) => {
                    const item = data.find((d) => d.time === value)
                    return item?.label || value
                  }}
                />
                {graphType === "hrv" ? (
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#3b82f6"
                    strokeWidth={3}
                    dot={{ fill: "#3b82f6", strokeWidth: 2, r: 5 }}
                    activeDot={{ r: 7, stroke: "#3b82f6", strokeWidth: 2 }}
                  />
                ) : (
                  <>
                    <Line
                      type="monotone"
                      dataKey="heartRate"
                      stroke="#ef4444"
                      strokeWidth={3}
                      dot={{ fill: "#ef4444", strokeWidth: 2, r: 5 }}
                      name="Heart Rate (BPM)"
                    />
                    <Line
                      type="monotone"
                      dataKey="foodIntake"
                      stroke="#22c55e"
                      strokeWidth={3}
                      dot={{ fill: "#22c55e", strokeWidth: 2, r: 5 }}
                      name="Food Intake Level"
                    />
                  </>
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Graph Legend */}
          <div className="mt-4 flex justify-center gap-6">
            {graphType === "hrv" ? (
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full" />
                <span className="text-sm text-gray-600">HRV (ms)</span>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full" />
                  <span className="text-sm text-gray-600">Heart Rate</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full" />
                  <span className="text-sm text-gray-600">Food Intake</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function HeartDetailedReport() {
  const navigate = useNavigate()
  const [activePopup, setActivePopup] = useState(null)
  const [heartRateData, setHeartRateData] = useState({
    current: 72,
    hrv: 45,
    cardiovascularScore: 85,
    stressScore: 32,
    riskLevel: "Normal",
  })

  const handleGraphOpen = (graphType) => {
    setActivePopup(graphType)
  }

  const handleGraphClose = () => {
    setActivePopup(null)
  }

  const getRiskBadgeColor = (risk) => {
    switch (risk.toLowerCase()) {
      case "normal":
        return "bg-green-100 text-green-700 border-green-200"
      case "elevated":
        return "bg-yellow-100 text-yellow-700 border-yellow-200"
      case "high":
        return "bg-red-100 text-red-700 border-red-200"
      default:
        return "bg-gray-100 text-gray-700 border-gray-200"
    }
  }

  // Simplified AI suggestions - only 2 points
  const aiSuggestions = [
    "Your cardiovascular health is excellent. Continue current exercise routine and maintain consistent sleep schedule for optimal HRV.",
    "Consider monitoring heart rate response to meals and reducing caffeine intake after 2 PM to optimize evening heart rate patterns.",
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="px-6 pb-8 rounded-b-[2rem]">
        <div className="flex items-center gap-4 pt-8 mb-6">
          <Button
            onClick={() => navigate("/dashboard")}
            variant="outline"
            size="icon"
            className="h-12 w-12 rounded-xl border-gray-200 bg-white hover:bg-gray-50"
          >
            <ArrowLeft className="h-6 w-6 text-black" />
          </Button>
          <h1 className="text-2xl font-bold text-black">Heart Analysis Report</h1>
        </div>
      </div>

      <div className="px-6 -mt-4 space-y-6">
        {/* Main Vitals Card */}
        <Card className="bg-white border border-gray-200 rounded-2xl overflow-hidden">
          <CardContent className="p-6">
            {/* Heart Rate and HRV Row */}
            <div className="grid grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  <span className="text-sm font-medium text-gray-600">Heart Rate</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold text-gray-900">{heartRateData.current}</span>
                  <span className="text-lg text-gray-500">BPM</span>
                </div>
                <div className="h-8 flex items-center">
                  <div className="flex space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <div
                        key={i}
                        className="w-1 bg-red-500 rounded-full animate-pulse"
                        style={{
                          height: `${Math.random() * 20 + 10}px`,
                          animationDelay: `${i * 0.1}s`,
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-blue-500" />
                  <span className="text-sm font-medium text-gray-600">HRV</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold text-gray-900">{heartRateData.hrv}</span>
                  <span className="text-lg text-gray-500">ms</span>
                </div>
                <div className="h-8 flex items-center">
                  <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500 rounded-full transition-all duration-1000"
                      style={{ width: `${(heartRateData.hrv / 100) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Scores Row */}
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <span className="text-sm font-medium text-gray-600">Cardiovascular Score</span>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-green-600">{heartRateData.cardiovascularScore}</span>
                  <span className="text-sm text-gray-500">/100</span>
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-sm font-medium text-gray-600">Stress Score</span>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-orange-500">{heartRateData.stressScore}</span>
                  <span className="text-sm text-gray-500">/100</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk Badge */}
        <div className="flex justify-center">
          <Badge
            className={`px-4 py-2 text-sm font-semibold rounded-full border ${getRiskBadgeColor(heartRateData.riskLevel)}`}
          >
            Risk Level: {heartRateData.riskLevel}
          </Badge>
        </div>

        {/* Heart Visualization with Arrows - No Background */}
        <div className="relative py-8">
          <div className="flex flex-col items-center space-y-6">
            {/* Top Arrow and HRV Analysis Button */}
            <div className="relative">
              <Button
                onClick={() => handleGraphOpen("hrv")}
                variant="ghost"
                className="flex items-center gap-2 px-6 py-3 rounded-xl hover:bg-blue-50 transition-colors group border border-blue-200 bg-white"
              >
                <ChevronUp className="h-5 w-5 text-blue-500 group-hover:text-blue-600" />
                <span className="text-sm font-medium text-blue-600 group-hover:text-blue-700">HRV Analysis</span>
              </Button>

              {/* Arrow pointing down to heart */}
              <div className="absolute top-full left-1/2 transform -translate-x-1/2">
                <div className="w-0.5 h-8 bg-blue-300"></div>
                <div className="w-0 h-0 border-l-[6px] border-r-[6px] border-t-[8px] border-l-transparent border-r-transparent border-t-blue-300"></div>
              </div>
            </div>

            {/* Animated Lottie Heart */}
            <div className="relative z-10">
              <LottieHeart />
            </div>

            {/* Bottom Arrow and Heart Rate Analysis Button */}
            <div className="relative">
              {/* Arrow pointing up from heart */}
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2">
                <div className="w-0 h-0 border-l-[6px] border-r-[6px] border-b-[8px] border-l-transparent border-r-transparent border-b-red-300"></div>
                <div className="w-0.5 h-8 bg-red-300"></div>
              </div>

              <Button
                onClick={() => handleGraphOpen("heartFood")}
                variant="ghost"
                className="flex items-center gap-2 px-6 py-3 rounded-xl hover:bg-red-50 transition-colors group border border-red-200 bg-white"
              >
                <span className="text-sm font-medium text-red-600 group-hover:text-red-700">Heart Rate & Food</span>
                <ChevronDown className="h-5 w-5 text-red-500 group-hover:text-red-600" />
              </Button>
            </div>
          </div>
        </div>

        {/* AI Health Insights - Simplified with 2 points */}
        <div className="bg-white border border-gray-200 rounded-2xl p-6 mb-8">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
              <Brain className="h-5 w-5 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Health Insights</h3>
              <div className="space-y-4">
                {aiSuggestions.map((suggestion, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-sm text-gray-700 leading-relaxed">{suggestion}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Graph Popups */}
      <GraphPopup
        isOpen={activePopup === "hrv"}
        onClose={handleGraphClose}
        graphType="hrv"
        data={hrvData}
        title="HRV Variability Analysis"
      />

      <GraphPopup
        isOpen={activePopup === "heartFood"}
        onClose={handleGraphClose}
        graphType="heartFood"
        data={heartRateWithFoodData}
        title="Heart Rate & Food Correlation"
      />

      <style jsx>{`
        @keyframes animate-in {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
        
        .animate-in {
          animation: animate-in 0.2s ease-out;
        }
        
        .zoom-in-95 {
          animation: animate-in 0.2s ease-out;
        }
      `}</style>
    </div>
  )
}
